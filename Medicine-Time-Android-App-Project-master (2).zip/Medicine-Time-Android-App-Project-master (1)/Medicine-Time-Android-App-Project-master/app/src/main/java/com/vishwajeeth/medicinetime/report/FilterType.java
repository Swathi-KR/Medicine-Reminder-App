package com.vishwajeeth.medicinetime.report;

/**
 * Created by vishwajeeth on 13/07/17.
 */

public enum  FilterType {

    ALL_MEDICINES,

    TAKEN_MEDICINES,

    IGNORED_MEDICINES
}
